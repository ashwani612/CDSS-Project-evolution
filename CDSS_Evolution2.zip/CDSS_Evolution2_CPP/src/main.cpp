#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <cctype>

using namespace std;

const string DATA_FILE = "data/patients.csv";

struct Patient {
    string id, name;
    int age = 0;
    string gender, symptoms;
};

string trim(const string& s) {
    size_t start = s.find_first_not_of(" \t\r\n");
    if (start == string::npos) return "";
    size_t end = s.find_last_not_of(" \t\r\n");
    return s.substr(start, end - start + 1);
}

bool containsComma(const string& s) {
    return s.find(',') != string::npos;
}

vector<Patient> loadPatients() {
    vector<Patient> patients;
    ifstream file(DATA_FILE);
    string line;

    while (getline(file, line)) {
        stringstream ss(line);
        Patient p;
        string ageText;

        if (!getline(ss, p.id, ',')) continue;
        if (!getline(ss, p.name, ',')) continue;
        if (!getline(ss, ageText, ',')) continue;
        if (!getline(ss, p.gender, ',')) continue;
        if (!getline(ss, p.symptoms)) continue;

        try {
            p.age = stoi(ageText);
            patients.push_back(p);
        } catch (...) {
            continue;
        }
    }
    return patients;
}

void savePatients(const vector<Patient>& patients) {
    ofstream file(DATA_FILE);
    if (!file) {
        cout << "Error: Could not open data/patients.csv for writing.\n";
        return;
    }

    for (const auto& p : patients) {
        file << p.id << ',' << p.name << ',' << p.age << ','
             << p.gender << ',' << p.symptoms << '\n';
    }
}

bool idExists(const string& id, const vector<Patient>& patients) {
    for (const auto& p : patients) {
        if (p.id == id) return true;
    }
    return false;
}

bool validName(const string& name) {
    if (name.empty()) return false;
    for (unsigned char ch : name) {
        if (!isalpha(ch) && ch != ' ') return false;
    }
    return true;
}

int readAge() {
    string input;
    while (true) {
        cout << "Enter age (1-120): ";
        getline(cin, input);
        input = trim(input);

        if (!input.empty() && all_of(input.begin(), input.end(),
            [](unsigned char ch) { return isdigit(ch); })) {
            try {
                int age = stoi(input);
                if (age >= 1 && age <= 120) return age;
            } catch (...) {}
        }
        cout << "Invalid age. Please enter a number from 1 to 120.\n";
    }
}

string readGender() {
    string gender;
    while (true) {
        cout << "Enter gender (Male/Female/Other): ";
        getline(cin, gender);
        gender = trim(gender);

        string lower = gender;
        transform(lower.begin(), lower.end(), lower.begin(),
                  [](unsigned char ch) { return static_cast<char>(tolower(ch)); });

        if (lower == "male") return "Male";
        if (lower == "female") return "Female";
        if (lower == "other") return "Other";
        cout << "Please enter Male, Female, or Other.\n";
    }
}

string readCommaFree(const string& prompt, bool allowEmpty = false) {
    string value;
    while (true) {
        cout << prompt;
        getline(cin, value);
        value = trim(value);

        if ((!allowEmpty && value.empty()) || containsComma(value)) {
            cout << "This field cannot be empty and must not contain commas.\n";
            continue;
        }
        return value;
    }
}

void registerPatient() {
    vector<Patient> patients = loadPatients();
    Patient p;

    cout << "\n--- Register Patient ---\n";
    while (true) {
        p.id = readCommaFree("Enter patient ID: ");
        if (!idExists(p.id, patients)) break;
        cout << "This patient ID already exists. Enter a different ID.\n";
    }

    while (true) {
        cout << "Enter patient name: ";
        getline(cin, p.name);
        p.name = trim(p.name);
        if (validName(p.name)) break;
        cout << "Invalid name. Use letters and spaces only.\n";
    }

    p.age = readAge();
    p.gender = readGender();
    p.symptoms = readCommaFree("Enter symptoms (short description): ", true);

    patients.push_back(p);
    savePatients(patients);
    cout << "Patient registered successfully.\n";
}

void printPatient(const Patient& p) {
    cout << "\nPatient ID: " << p.id
         << "\nName: " << p.name
         << "\nAge: " << p.age
         << "\nGender: " << p.gender
         << "\nSymptoms: " << p.symptoms << "\n";
}

void viewPatients() {
    vector<Patient> patients = loadPatients();
    cout << "\n--- All Patients ---\n";
    if (patients.empty()) {
        cout << "No patient records found.\n";
        return;
    }

    for (const auto& p : patients) printPatient(p);
    cout << "\nTotal patients: " << patients.size() << "\n";
}

void searchPatient() {
    vector<Patient> patients = loadPatients();
    string id = readCommaFree("\nEnter patient ID to search: ");

    for (const auto& p : patients) {
        if (p.id == id) {
            cout << "\nPatient found:\n";
            printPatient(p);
            return;
        }
    }
    cout << "Patient not found.\n";
}

void updatePatient() {
    vector<Patient> patients = loadPatients();
    string id = readCommaFree("\nEnter patient ID to update: ");

    for (auto& p : patients) {
        if (p.id == id) {
            cout << "Updating patient " << p.id << ".\n";

            while (true) {
                cout << "Enter new name: ";
                getline(cin, p.name);
                p.name = trim(p.name);
                if (validName(p.name)) break;
                cout << "Invalid name. Use letters and spaces only.\n";
            }

            p.age = readAge();
            p.gender = readGender();
            p.symptoms = readCommaFree("Enter new symptoms: ", true);

            savePatients(patients);
            cout << "Patient updated successfully.\n";
            return;
        }
    }
    cout << "Patient not found.\n";
}

void deletePatient() {
    vector<Patient> patients = loadPatients();
    string id = readCommaFree("\nEnter patient ID to delete: ");

    auto it = remove_if(patients.begin(), patients.end(),
        [&](const Patient& p) { return p.id == id; });

    if (it == patients.end()) {
        cout << "Patient not found.\n";
        return;
    }

    patients.erase(it, patients.end());
    savePatients(patients);
    cout << "Patient deleted successfully.\n";
}

void showTotalPatients() {
    cout << "\nTotal patients: " << loadPatients().size() << "\n";
}

int main() {
    // Run this program from the project root folder (CDSS_Evolution2_CPP).
    int choice = 0;

    do {
        cout << "\n========================================\n";
        cout << "   CLINICAL DECISION SUPPORT SYSTEM\n";
        cout << "              EVOLUTION 2\n";
        cout << "========================================\n";
        cout << "1. Register Patient\n";
        cout << "2. View All Patients\n";
        cout << "3. Search Patient by ID\n";
        cout << "4. Update Patient\n";
        cout << "5. Delete Patient\n";
        cout << "6. Total Patients\n";
        cout << "7. Exit\n";
        cout << "\nEnter your choice: ";

        string input;
        getline(cin, input);
        try {
            size_t pos = 0;
            choice = stoi(input, &pos);
            if (pos != input.size()) choice = 0;
        } catch (...) {
            choice = 0;
        }

        switch (choice) {
            case 1: registerPatient(); break;
            case 2: viewPatients(); break;
            case 3: searchPatient(); break;
            case 4: updatePatient(); break;
            case 5: deletePatient(); break;
            case 6: showTotalPatients(); break;
            case 7: cout << "Exiting CDSS Evolution 2.\n"; break;
            default: cout << "Invalid choice. Please select 1-7.\n";
        }
    } while (choice != 7);

    return 0;
}
