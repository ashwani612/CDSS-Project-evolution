# CDSS - Evolution 2

Clinical Decision Support System (educational console prototype).

## Features
- Register a patient
- View all patients
- Search patient by ID
- Update patient details
- Delete a patient
- Prevent duplicate patient IDs
- Validate patient name and age
- Store records in `data/patients.csv`
- Display total patient count

## Requirements
- MinGW-w64 / g++ with C++17
- Visual Studio Code (or another C++ editor)

## Run from the project root
Open the `CDSS_Evolution2_CPP` folder in VS Code, then open a terminal in that folder.

Compile:
```bash
g++ -std=c++17 src/main.cpp -o CDSS_Evolution2.exe
```

Run in PowerShell:
```powershell
.\CDSS_Evolution2.exe
```

Important: Run the program while the terminal is in the project root folder so it can find `data/patients.csv`.

## CSV format
Each row stores:
`patient_id,name,age,gender,symptoms`

Do not enter commas inside fields because this starter version uses a simple CSV format.

## Disclaimer
This is an educational software project, not a medical device. It does not provide clinically validated diagnosis or treatment recommendations. Do not enter real patient information.
